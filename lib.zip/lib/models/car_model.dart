class Car {
  final String name;
  final int seats;
  final int price;

  const Car({
    required this.name,
    required this.seats,
    required this.price,
  });
}