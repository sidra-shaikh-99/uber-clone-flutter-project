import 'package:flutter/material.dart';
import '../models/car_model.dart';
import 'success_screen.dart';
import '../widgets/custom_button.dart';

class ConfirmScreen extends StatelessWidget {
  final Car car;
  final String pickup;
  final String destination;
  final int passengers;

  const ConfirmScreen({
    super.key,
    required this.car,
    required this.pickup,
    required this.destination,
    required this.passengers,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Confirm Ride"),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // 🔲 Ride Details Card
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _row("📍 Pickup", pickup),
                    const SizedBox(height: 10),
                    _row("🏁 Destination", destination),
                    const Divider(height: 25),
                    _row("🚗 Car", car.name),
                    _row("👥 Passengers", passengers.toString()),
                    _row("💰 Price", "₹${car.price}"),
                  ],
                ),
              ),
            ),

            const Spacer(),

            // 🔘 Confirm Button
            CustomButton(
              text: "Confirm Ride",
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const SuccessScreen(),
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  // 🔹 Reusable Row Widget
  Widget _row(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: const TextStyle(fontSize: 16)),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }
}