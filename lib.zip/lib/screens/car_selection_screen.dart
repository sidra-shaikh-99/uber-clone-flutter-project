import 'package:flutter/material.dart';
import '../models/car_model.dart';
import 'passenger_screen.dart';

class CarSelectionScreen extends StatelessWidget {
  final String pickup;
  final String destination;

  const CarSelectionScreen({
    super.key,
    required this.pickup,
    required this.destination,
  });

  final List<Car> cars = const [
    Car(name: "Mini", seats: 4, price: 100),
    Car(name: "Sedan", seats: 4, price: 150),
    Car(name: "SUV", seats: 6, price: 250),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Select Car"),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView.builder(
          itemCount: cars.length,
          itemBuilder: (context, index) {
            final car = cars[index];

            return Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: const Icon(Icons.directions_car, size: 30),
                title: Text(
                  car.name,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text("${car.seats} seats"),
                trailing: Text(
                  "₹${car.price}",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PassengerScreen(
                        car: car,
                        pickup: pickup,
                        destination: destination,
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}