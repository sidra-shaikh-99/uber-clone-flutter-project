import 'package:flutter/material.dart';
import '../models/car_model.dart';
import 'confirm_screen.dart';
import '../widgets/custom_button.dart';

class PassengerScreen extends StatefulWidget {
  final Car car;
  final String pickup;
  final String destination;

  const PassengerScreen({
    super.key,
    required this.car,
    required this.pickup,
    required this.destination,
  });

  @override
  State<PassengerScreen> createState() => _PassengerScreenState();
}

class _PassengerScreenState extends State<PassengerScreen> {
  int count = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Passengers"),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // 🚗 Car Info
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 4,
              child: ListTile(
                leading: const Icon(Icons.directions_car),
                title: Text(widget.car.name),
                subtitle: Text("Max ${widget.car.seats} seats"),
              ),
            ),

            const SizedBox(height: 30),

            // 👥 Passenger Counter
            const Text(
              "Select Passengers",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _circleButton(Icons.remove, () {
                  if (count > 1) {
                    setState(() => count--);
                  }
                }),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "$count",
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                _circleButton(Icons.add, () {
                  if (count < widget.car.seats) {
                    setState(() => count++);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          "Max ${widget.car.seats} passengers allowed",
                        ),
                      ),
                    );
                  }
                }),
              ],
            ),

            const Spacer(),

            // 🔘 Continue Button
            CustomButton(
              text: "Continue",
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ConfirmScreen(
                      car: widget.car,
                      pickup: widget.pickup,
                      destination: widget.destination,
                      passengers: count,
                    ),
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  // 🔘 Circular Button
  Widget _circleButton(IconData icon, VoidCallback onTap) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black,
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: Colors.white),
      ),
    );
  }
}